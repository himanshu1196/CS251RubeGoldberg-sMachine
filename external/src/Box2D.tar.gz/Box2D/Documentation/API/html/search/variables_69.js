var searchData=
[
  ['i',['I',['../structb2_mass_data.html#ad2d06e96e2d79d895df16ae0e5fe0376',1,'b2MassData']]],
  ['id',['id',['../structb2_manifold_point.html#afa7ec272b2b27abe129540f8fbe57fc5',1,'b2ManifoldPoint']]],
  ['indexa',['indexA',['../structb2_contact_feature.html#a833bc746e7cb5e3cd458f1c0809101d0',1,'b2ContactFeature::indexA()'],['../structb2_simplex_cache.html#ab574159e69dda7e14ead8de848ca6b67',1,'b2SimplexCache::indexA()']]],
  ['indexb',['indexB',['../structb2_contact_feature.html#ad96712b6a0cc1f4b22b85b5948eab81d',1,'b2ContactFeature::indexB()'],['../structb2_simplex_cache.html#ab7586465ee2c5f7c3bdd8f80d5e256a7',1,'b2SimplexCache::indexB()']]],
  ['issensor',['isSensor',['../structb2_fixture_def.html#ac8cfcc6208663c92861eaab3b3fdc57e',1,'b2FixtureDef']]],
  ['iterations',['iterations',['../structb2_distance_output.html#ae2d4c84dd3d05ea4f4d20c91099ec8d5',1,'b2DistanceOutput']]]
];
